import java.util.ArrayList;
import java.util.Scanner;

public class GerenciamentoFuncionarios {
    public static void main(String[] args) {
        ArrayList<Funcionario> funcionarios = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("1. Adicionar Funcionario");
            System.out.println("2. Remover Funcionario");
            System.out.println("3. Exibir Todos os Funcionarios");
            System.out.println("4. Buscar Funcionario por Nome ou Matricula");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opcao: ");
            int opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    adicionarFuncionario(funcionarios, scanner);
                    break;
                case 2:
                    removerFuncionario(funcionarios, scanner);
                    break;
                case 3:
                    exibirFuncionarios(funcionarios);
                    break;
                case 4:
                    buscarFuncionario(funcionarios, scanner);
                    break;
                case 5:
                    System.out.println("Saindo...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opcao invalida.");
            }
        }
    }

    private static void adicionarFuncionario(ArrayList<Funcionario> funcionarios, Scanner scanner) {
        System.out.print("\nDigite o tipo de funcionario (1 - Gerente, 2 - Desenvolvedor, 3 - Estagiario): ");
        int tipo = scanner.nextInt();

        System.out.print("Digite o nome do funcionario: ");
        String nome = scanner.nextLine();
        System.out.print("Digite a matricula do funcionario: ");
        String matricula = scanner.nextLine();

        switch (tipo) {
            case 1:
                System.out.print("Digite o bonus anual do gerente: ");
                double bonusAnual = scanner.nextDouble();
                System.out.print("Digite a equipe sob gerencia do gerente: ");
                String equipe = scanner.nextLine();
                funcionarios.add(new Gerente(nome, matricula, bonusAnual, equipe));
                break;
            case 2:
                System.out.print("Digite as tecnologias que o desenvolvedor domina");
                String[] tecnologiasArray = scanner.nextLine();
                ArrayList<String> tecnologias = new ArrayList<>();
                for (String tecnologia : tecnologiasArray) {
                    tecnologias.add(tecnologia);
                }
                funcionarios.add(new Desenvolvedor(nome, matricula, tecnologias));
                break;
            case 3:
                System.out.print("Digite o numero de horas trabalhadas pelo estagiario: ");
                int horasTrabalhadas = scanner.nextInt();
                System.out.print("Digite o nome do supervisor do estagiario: ");
                String supervisor = scanner.nextLine();
                funcionarios.add(new Estagiario(nome, matricula, horasTrabalhadas, supervisor));
                break;
            default:
                System.out.println("Tipo de funcionario invalido.");
        }
        System.out.println("Funcionario adicionado com sucesso.");
    }

    private static void removerFuncionario(ArrayList<Funcionario> funcionarios, Scanner scanner) {
        System.out.print("\nDigite a matricula do funcionario a ser removido: ");
        String matricula = scanner.nextLine();

        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getMatricula().equals(matricula)) {
                funcionarios.remove(funcionario);
                System.out.println("Funcionario removido com sucesso.");
                return;
            }
        }
    System.out.println("Funcionario nao encontrado.");
    }

    private static void exibirFuncionarios(ArrayList<Funcionario> funcionarios) {
        System.out.println("\nLista de Funcionarios:");
        for (Funcionario funcionario : funcionarios) {
            System.out.println(funcionario.getNome() + " - Matricula: " + funcionario.getMatricula() + " - Salario: R$ " + funcionario.calcularSalario());
        }
    }
    private static void buscarFuncionario(ArrayList<Funcionario> funcionarios, Scanner scanner) {
        System.out.print("\nDigite o nome ou a matricula do funcionario a ser buscado: ");
        String busca = scanner.nextLine();

        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getNome().equalsIgnoreCase(busca) || funcionario.getMatricula().equals(busca)) {
                System.out.println("Funcionario encontrado:");
                System.out.println(funcionario.getNome() + " - Matricula: " + funcionario.getMatricula() + " - Salario: R$ " + funcionario.calcularSalario());
                return;
            }
        }
        System.out.println("Funcionario nao encontrado");
    }
}