interface Trabalhavel {
    void trabalhar();
    void relatarProgresso();
}

class Estagiario extends Funcionario implements Trabalhavel {
    private int horasTrabalhadas;
    private String supervisor;

    public Estagiario(String nome, String matricula, int horasTrabalhadas, String supervisor) {
        super(nome, matricula);
        this.horasTrabalhadas = horasTrabalhadas;
        this.supervisor = supervisor;
    }

    @Override
    public double calcularSalario() {
        return horasTrabalhadas * 10;
    }

    @Override
    public void trabalhar() {
        System.out.println("Estagiario " + getNome() + " esta aprendendo e trabalhando sob supervisao.");
    }

    @Override
    public void relatarProgresso() {
        System.out.println("Estagiario " + getNome() + " esta relatando o progresso de suas atividades.");
    }
}